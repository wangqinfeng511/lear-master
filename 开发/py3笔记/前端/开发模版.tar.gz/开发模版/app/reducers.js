/**
 * Created by root on 16-11-4.
 */
import  combineReducers from 'redux/lib/combineReducers'; //用于把多个reducers合并起来
import * as Actions from './actions';
const  initialState={
    next_id:0,
    todos:[],
    filter:'todo'
}   //第一次调用给的state初始值


function todoApp(state=initialState, action) {  //reducer 的方法是要交给框架使用的，对定义的方法有参数要求! 当前的state，action 传入的action
    let todos=[]
    switch (action.type) {
        case Actions.ADD_TYPE:
            const todo={id:state.next_id,content:action.content,done:false}
            return Object.assign({},state,{next_id:state.next_id+1,
                todos:[...state.todos,todo]})
        case  Actions.DONE_TYPE:
            todos=state.todos;
            todos.find(it =>it.id===action.id).done=true;
            return Object.assign({},state,{todos});
        case Actions.REOPEN_TYPE:
            todos=state.todos;
            todos.find(it =>it.id===action.id).done=false;
            return Object.assign({},state,{todos});
        case  Actions.FILTER_TYPE:
            return Object.assign({},state,{filter:action.fl});
        default:
            return state;

    }
}

const rootReducer = combineReducers(
    {
        todoApp
    }
);
export default rootReducer;