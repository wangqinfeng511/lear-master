/**
 * Created by root on 16-11-4.
 */
import React from 'react';
export default class rootComponent extends React.Component{
    render(){
        return <div>hello word </div>
    }
}