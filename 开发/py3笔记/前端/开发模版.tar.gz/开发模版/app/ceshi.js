/**
 * Created by root on 16-11-4.
 */

a={a:1};
b={b:2};
c={c:3};
console.log(Object.assign( {},a,b,c));
//console.log()