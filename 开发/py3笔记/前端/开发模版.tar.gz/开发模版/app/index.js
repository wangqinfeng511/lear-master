/**
 * Created by comyn on 16-10-29.
 */
import React from 'react';
import ReactDOM from 'react-dom';
//import Login from './login';
import App from './app'
//redux import
import createStore from 'redux/lib/createStore';
import rootReducer from './reducers';
import Provider from 'react-redux/lib/components/Provider'; //连接react 至redux
class Ts extends React.Component{
    render(){
        return(<div>
            {/*<App  />*/}
            hello word
        </div>)
    }

}
/////////////////////////redux
const store=createStore(rootReducer);//参数是引入的reducers规则文件
/////////////////////////
//<Provide store={store引入的规则}> <APP入口组件 /> </Provide>  把组件关联至store规则。
ReactDOM.render(
    <Provider store={store}>
    <Ts />
</Provider>,root);

if (module.hot) {
    //热加载设置，关注为./reducer的变化进行加载
    module.hot.accept('./reducers', () => {
        const nextReducer = require('./reducers');
        store.replaceReducer(nextReducer);

    })
}
