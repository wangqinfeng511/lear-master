/**
 * Created by root on 16-10-31.
 */
import React from 'react';
import connect from 'react-redux/lib/components/connect';//redux 分发到视图
import * as Action from './actions' //import actions

//使用方法,传入一个state 使用装钸器.babelrc要添加装饰器转换器  transform-decorators-legacy并npm i  transform-decorators-legacy --save-dev

class  NewTODOComponent extends React.Component{
    constructor(props){
        super(props)
        this.state={value:''}
        this.handleNewToDO=this.handelNewTodo.bind(this);
    }
    handelNewTodo(){
        this.props.onTODOCreated(this.state.value);
        this.setState(this.state={value:''});
    }
    render(){
        return(
            <div>
                <form className="pure-form" >
            <fieldset>
                <legend>事件记录</legend>
                <input type="text"  value={this.state.value} onChange={e=> this.setState({value:e.target.value})}/>
                <button type="button" onClick={this.handleNewToDO} className="pure-button pure-button-primary">录入</button>
                </fieldset>
            </form>
            </div>
        )
    }
}

class  TODOComponent extends React.Component{
    constructor(props){
        super(props);
        this.state={todos: []}
    }
    handlechange(e){
        if(e.target.checked){
            this.props.onComplate(this.props.id)
        }
    }
    render(){
        return (
                <div className="prue-g">
                    <div className="prue-u-1-24">
                        <input type="checkbox" onChange={()=>this.handlechange}/>
                    </div>
                    <div className="prue-u-1-23">{this.props.content}</div>
                </div>
            )
    }
}
class  TODOListComponent extends React.Component{
    render(){
            return(
                <div>
                    {
                        this.props.todos.map((it, i) => <TODOComponent id={i} key={i} content={it.content}
                                                                       onComplate={this.props.onComplate} />)
                    }

                </div>
            )
    }
}

@conne

export default class RootComponent extends React.Component{
    constructor(props){
        super(props);
        this.state={todos:[]};
        this.handleNewToDO=this.handleNewToDO.bind(this);
        this.handleComplateToDO=this.handleComplateToDO.bind(this)
    }

    handleNewToDO(value){
        const todo = {content:value,isCOmplate:false};
        const todos = this.state.todos;
        todos.push(todo);
        this.setState({todos:todos});
    }
    handleComplateToDO(id){
        const todos=this.state.todos;
        todos[id].isCOmplate =true;
        this.setState({todos:todos});
    }
    render(){
        return (
            <div>
                <NewTODOComponent onTODOCreated={this.handleNewToDO}/>
                <TODOListComponent todos={this.state.todos.filter(it =>!it.isCOmplate)} onComplate={this.handleComplateToDO}/>
            </div>
        )
    }
}
