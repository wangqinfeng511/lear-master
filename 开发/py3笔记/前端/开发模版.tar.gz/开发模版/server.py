from my_m import Route,Application
route=Route
class storage:
    def __init__(self):
        self.next_id = 0
        self.todos=[]
    def add(self,content):
        self.todos.append({'id': self.next_id, 'content': content, 'done': False})
        self.next_id+=1;
    def done(self,id):
        for todo in self.todos:
            if todo['id'] == id:
                todo['done'] =True
                break
    def reopen(self, id):
        for todo in self.todos:
            if todo['id'] == id:
                todo['done'] = False
                break
    def list(self,filter='todo'):
        if filter=='todo':
            return  [t for t in self.todos if not t['done']]
        return self.todos

