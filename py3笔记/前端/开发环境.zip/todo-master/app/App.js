/**
 * Created by comyn on 16-10-29.
 */
import React from 'react';

export default class App extends React.Component {
    render() {
        return (
            <div>abcd</div>
        )
    }
}